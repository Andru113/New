package com.company;

public abstract class Animal {
    public  Boolean eats;
    public  Boolean sleps;
    public Boolean voise;
    public String voises;
    public abstract Boolean getEat();
    public abstract  void  setEat(Boolean eats);
    public abstract Boolean getSlep();
    public abstract  void  setSlept(Boolean sleps);
    public abstract String getVoise();
    public abstract  void  setVoise(Boolean voise);
}
