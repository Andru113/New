package com.company;

public class Main {

    public static void main(String[] args) {
	Cat cat=new Cat();
	    cat.setEat(true);
	    cat.getEat();
	    cat.setSlept(true);
		cat.getSlep();
		cat.setVoise(false);
		System.out.println(cat.getVoise());
		Dog dog=new Dog();
		dog.setEat(false);
		dog.getEat();
		dog.setSlept(true);
		dog.getSlep();
		dog.setVoise(true);
		System.out.println(dog.getVoise());
		Rawen rawen=new Rawen();
		rawen.setEat(true);
		rawen.getEat();
		rawen.setSlept(true);
		rawen.getSlep();
		rawen.setVoise(true);
		System.out.println(rawen.getVoise());
    }
}
