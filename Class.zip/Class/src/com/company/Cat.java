package com.company;

public class Cat extends Animal {
    @Override
    public Boolean getEat() {
        if (eats==true)
        {
            System.out.println("Кот ест");
        }
        else
        {System.out.println("Кот не ест");}
        return eats;
    }

    @Override
    public void setEat(Boolean eats) {
this.eats=eats;
    }

    @Override
    public Boolean getSlep() {
        if (eats==true)
        {sleps=false;}
        if (sleps==true)
        {
            System.out.println("Кот спит");
        }
        else
        {System.out.println("Кот не спит");}
        return sleps;
    }

    @Override
    public void setSlept(Boolean sleps) {
this.sleps=sleps;
    }

    @Override
    public String getVoise() {
        if (sleps==true)
        {voise=false;}
        if (voise==false)
        {
            voises="Кот мочит";
        }
        else
        {voises="Мяу";}
        return voises;
    }

    @Override
    public void setVoise(Boolean voise) {
this.voise=voise;
    }
}
