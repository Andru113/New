package com.company;

public class Dog extends Animal {
    @Override
    public Boolean getEat() {
        if (eats==true)
        {
            System.out.println("Собака ест");
        }
        else
        {System.out.println("Собака не ест");}
        return eats;
    }

    @Override
    public void setEat(Boolean eats) {
        this.eats=eats;
    }

    @Override
    public Boolean getSlep() {
        if (eats==true)
        {sleps=false;}
        if (sleps==true)
        {
            System.out.println("Собака спит");
        }
        else
        {System.out.println("Собака не спит");}
        return sleps;
    }

    @Override
    public void setSlept(Boolean sleps) {
        this.sleps=sleps;
    }

    @Override
    public String getVoise() {
        if (sleps==true)
        {voise=false;}
        if (voise==false)
        {
            voises="Собака мочит";
        }
        else
        {voises="Гав";}
        return voises;
    }

    @Override
    public void setVoise(Boolean voise) {
        this.voise=voise;
    }
}
